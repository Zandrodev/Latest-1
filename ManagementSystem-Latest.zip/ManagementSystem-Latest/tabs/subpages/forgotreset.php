<?php
// Start session
session_start();

// Check for errors in session variables
$errors = isset($_SESSION['errors']) ? $_SESSION['errors'] : array();
unset($_SESSION['errors']);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title>
    <link rel="stylesheet" href="forgotreset.css">
</head>
<body>
<img class="images" src="img/est-transparent.png">
<div id="container">
        <h2>Password</h2>
        <p>Create a strong unique password.</p>
        <div id="line"></div>
        <?php if (!empty($errors)) { ?>
            <div id="alert">
                <ul>
                    <?php foreach ($errors as $error) { ?>
                        <li style="list-style-type: none;"><?php echo $error; ?></li>
                    <?php } ?>
                </ul>
            </div>
        <?php } ?>
        <form action="forgotresetdb.php?Token=<?php echo $_GET['Token']; ?>" method="POST" autocomplete="off">
            <input type="password" name="password" placeholder="Password" required><br>
            <input type="password" name="confirmPassword" placeholder="Confirm Password" required><br>
            <input type="submit" name="changePassword" value="Save">
        </form>
    </div>
</body>
</html>