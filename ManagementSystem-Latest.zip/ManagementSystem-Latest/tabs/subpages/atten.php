<?php
$allowed_ip = '192.168.1.8/'; // IP address of the WiFi network

if ($_SERVER['REMOTE_ADDR'] != $allowed_ip) {
    // deny access to the PHP page
    header('HTTP/1.0 403 Forbidden ');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <title>Attendance</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="attendance.css">
    <link href='Admin/boxicons-2.1.4/css/boxicons.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <?php 
include("auth.php");
?>
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <div class="logo_name">
          <img class="Images" src="img/est-transparent.png">
      </div>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
        <a href="dashemployee.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
     <li>
       <a href="Atten.php">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <span class="tooltip">Attendance</span>
     </li>
     <li>
       <a href="Taskcheck.php">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Task Check</span>
       </a>
       <span class="tooltip">Task Check</span>
     </li>
     <li>
       <a href="fileleavecheck.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
       <span class="tooltip">Filing Leave</span>
     </li>
     <li>
     <li class="profile">
         <div class="profile-details">
           <!--<img src="profile.jpg" alt="profileImg">-->
           <div class="name_job">
             <div class="name"><?php
               echo " " .$_SESSION['Name']
               ?></div>
             <div class="job"><?php
               echo " " .$_SESSION['Department']
               ?></div>
         </div>
         <form action="logout.php" method="POST">

         <button type="submit" class='bx bx-log-out' id="log_out" ></i>
           </form>
     </li>
    </ul>
  </div>
  <div class="topd">
        <h1>University of Cebu Banilad<h1>
</div>
  <section class="home-section">
  <div class="text">
    <div class ="title"><h2>Attendance<h2>
</div>
<?php


$host = "localhost";
$username = "root";
$password = "";
$dbname = "demologin";

$conn = mysqli_connect($host,$username,$password,$dbname);
date_default_timezone_set('Asia/Manila');

if ($conn)
{
  echo "";
}
else {
  echo "Connection failed".mysqli_connect_error();
}


// Assuming you have already established a database connection
$UserID = $_SESSION['UserID'];
$date = date("Y-m-d");

// Query the attendance table to get the user's attendance record for today
// Query the attendance table to get the user's attendance record for today
// Query the attendance table to get the user's attendance record for today
$query = "SELECT status, Identify, timeout2 FROM attendance WHERE UserID = '$UserID' AND Date = '$date'";
$result = mysqli_query($conn, $query);

if (!$result) {
  // there's an error in the query
  echo "Error: " . mysqli_error($conn);
}

if (mysqli_num_rows($result) > 0) {
  // The user has an attendance record for today
  $row = mysqli_fetch_assoc($result);
  if (!is_null($row['timeout2'])) {
    // User has already clocked in and out, so display a message indicating that they have already clocked in and out
    echo 'You have already clocked in and out for today.';
  } else if ($row['Identify'] == 'Out') {
    // User has clocked out, so display the "clock in" button
    echo '<form method="post" action="attendance2.php">
            <button type="submit" class="status" name="Status2" value="Present">
            <img src="img/clockin.png" alt="clock in" class="img">
            </button>
          </form>';
  } else {
    // User has clocked in but not out, so display the "clock out" button
    echo '<form method="post" action="attendanceout.php">
            <button type="submit" class="status" name="clockout" value="Present">
            <img src="img/clockout.png" alt="clock in" class="img1">
            </button>
          </form>';
  }
} else {
  // The user does not have an attendance record for today, so display the "clock in" button
  echo '<form method="post" action="attendance.php">
          <button type="submit" class="status" name="Status" value="Present">
          <img src="img/clockin.png" alt="clock in" class="img">
          </button>
        </form>';
}


?>

  </div>
  </section>
  <script src="scripttest.js"></script>
</body>
</html>
