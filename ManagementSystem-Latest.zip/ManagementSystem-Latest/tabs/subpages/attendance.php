<?php
include("Admin/connection.php");

// Set the desired time for the user to click the present button
$desired_time = '08:00:00'; // for example, 12:20 AM

// Set the time after which the user will be marked as absent
$absent_time = '17:00:00'; // for example, 1:00 AM

date_default_timezone_set('Asia/Manila');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

// Get the user ID and attendance status from the form
$UserID = $_SESSION['UserID'];
$Name = $_SESSION['Name'];
$Department = $_SESSION['Department'];
$Status = $_POST['Status'];

// Get the current date and time
$date = date('Y-m-d');
$time = date('H:i:s');
$Identify = "In";

// Check if the user has an attendance record for today
$check_query = "SELECT * FROM attendance WHERE UserID='$UserID' AND Date='$date'";
$check_result = mysqli_query($conn, $check_query);

if (mysqli_num_rows($check_result) > 0) {
    // User already has an attendance record for today, can't input now
    header("Location: atten.php?error=already_recorded");
    exit();
} else {
    // User doesn't have an attendance record for today, check if present, late or absent
    if ($time <= $desired_time) {
        // User is present and on time
        $Status = 'Present';
    } elseif ($time > $desired_time && $time <= $absent_time) {
        // User is present but late
        $Status = 'Late';
    } else {
        // User is absent (did not click Present button) or has no attendance status yet
        $Status = 'Absent';
    }

    // Insert the attendance record into the database
    $insert_query = "INSERT INTO attendance (Name, UserID, Department, Date, Time, Status, timein1, Identify) 
                     VALUES ('$Name','$UserID', '$Department', '$date', '$time', '$Status', '$time', '$Identify')";
    
    if (mysqli_query($conn, $insert_query)) {
        header("Location: atten.php?success=attendance_recorded");
        exit();
    } else {
        echo "Error recording attendance: " . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
