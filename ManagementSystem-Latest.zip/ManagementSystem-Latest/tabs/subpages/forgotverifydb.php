<?php
// Start session
session_start();

// Connect to the database
$host = "localhost";
$username = "root";
$password = "";
$dbname = "demologin";

$db = mysqli_connect($host, $username, $password, $dbname);

if ($db) {
  echo "";
} else {
  echo "Connection failed" . mysqli_connect_error();
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Get the verification code from the form
    $verification_code = $_POST['OTPverify'];

    // Check if the verification code exists in the database
    $sql = "SELECT * FROM resettokens WHERE Token = '$verification_code'";
    $result = mysqli_query($db, $sql);
    $count = mysqli_num_rows($result);

    if ($count > 0) {
        // If the verification code is valid, redirect the user to the reset password page
        
        header('Location: forgotreset.php?Token=' . $verification_code);
        exit;
    } else {
        // If the verification code is invalid, display an error message
        $_SESSION['message'] = "Invalid verification code";
        header('Location: forgotverify.php');
        exit;
    }
}

?>