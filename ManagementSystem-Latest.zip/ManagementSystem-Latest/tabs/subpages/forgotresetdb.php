<?php
// Start session
session_start();

// Connect to the database
$host = "localhost";
$username = "root";
$password = "";
$dbname = "demologin";

$db = mysqli_connect($host, $username, $password, $dbname);

if ($db) {
  echo "";
} else {
  echo "Connection failed" . mysqli_connect_error();
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the new password from the form
    $new_password = mysqli_real_escape_string($db, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($db, $_POST['confirmPassword']);
    $Token = $_GET['Token'];

    // Validate password
    $errors = array();
    if (empty($new_password)) {
        $errors[] = "Password is required";
    }
    if (empty($confirm_password)) {
        $errors[] = "Confirm password is required";
    }
    if ($new_password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }
    if (strlen($new_password) < 8) {
        $errors[] = "Password must be at least 8 characters long";
    }

    // If there are no errors, update the password in the database
    if (empty($errors)) {
        $sql = "UPDATE loginform SET Password='$new_password' WHERE Email = (SELECT Email FROM resettokens WHERE Token = '$Token')";

        mysqli_query($db, $sql);

        // Delete the verification code from the database
        $sql = "DELETE FROM resettokens WHERE Token = '$Token'";
        mysqli_query($db, $sql);

        // Redirect the user to the login page
        header('location:forgotsuccess.php');
        exit;
    } else {
        // Store the error messages in session variables
        $_SESSION['errors'] = $errors;

        // Redirect the user back to the form page with error messages
        header('location:forgotreset.php?Token=' . urlencode($Token));
        exit;
    }
}

?>