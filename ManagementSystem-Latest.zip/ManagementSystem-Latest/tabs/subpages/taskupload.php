<?php
session_start();
  $uploads_dir = 'admin/attachmentsdb/';
  $allowed_types = array( 
    'image/jpeg',
    'image/png',
    'image/gif',
    'application/msword',
    'application/vnd.ms-excel',
    'application/vnd.ms-powerpoint',
    'application/pdf',
    'video/mp4', // Add video/mp4 for MP4 video files
    'video/quicktime', // Add video/quicktime for MOV video files
    'audio/*',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document' // Add docx file type
);

$max_size = array(
    'image/jpeg' => 500 * 1024 * 1024, // 500 MB
    'image/png' => 500 * 1024 * 1024, // 500 MB
    'image/gif' => 500 * 1024 * 1024, // 500 MB
    'application/msword' => 500 * 1024 * 1024, // 500 MB
    'application/vnd.ms-excel' => 500 * 1024 * 1024, // 500 MB
    'application/vnd.ms-powerpoint' => 500 * 1024 * 1024, // 500 MB
    'application/pdf' => 500 * 1024 * 1024, // 500 MB
    'video/mp4' => 500 * 1024 * 1024, // 500 MB
    'video/quicktime' => 500 * 1024 * 1024, // 500 MB
    'audio/*' => 500 * 1024 * 1024, // 500 MB
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 500 * 1024 * 1024 // 500 MB for docx files
);



  $host = "localhost";
  $username = "root";
  $password = "";
  $dbname = "demologin";
  date_default_timezone_set('Asia/Manila');
  $conn = mysqli_connect($host,$username,$password,$dbname);

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tmp_path = $_FILES['attachment_file']['tmp_name'];
    $filename = $_FILES['attachment_file']['name'];
    $filetype = $_FILES['attachment_file']['type'];
    $filesize = $_FILES['attachment_file']['size'];
    $TaskID = $_GET['TaskID'];
    $Datesubmitted1 = Date('y-m-d');
    $Timesubmitted = Date('h:i:s a');
    if (empty($filename)) {
      header('location:taskcheck.php?error=No file uploaded');
      exit();
    }
    if (!in_array($filetype, $allowed_types)) {
      header('location:taskcheck.php?error=No file uploaded');;
    }

    if ($filesize > $max_size) {
      die('Error: file size exceeds limit.');
    }
    
    $Datesubmitted = strtotime(date('Y-m-d')); // convert to Unix timestamp
$deadline_query = "SELECT Deadline FROM task WHERE TaskID = $TaskID";
$result = mysqli_query($conn, $deadline_query);
$row = mysqli_fetch_assoc($result);
$deadline = strtotime($row['Deadline']); // convert to Unix timestamp

if ($Datesubmitted > $deadline) {
  $is_late = "Late";
} else {
  $is_late = "Ontime";
}

// Update the task status and "IsLate" flag
if ($is_late == "Late") {
  $update_query = "UPDATE task SET Status = 'Pending', Ontime = 'Late', Datesubmitted = NOW() WHERE TaskID = $TaskID";
} else {
  $update_query = "UPDATE task SET Status = 'Pending', Ontime = 'Ontime', Datesubmitted = NOW() WHERE TaskID = $TaskID";
}
      mysqli_query($conn, $update_query);

    $target_path = $uploads_dir . $filename;

    if (move_uploaded_file($tmp_path, $target_path)) {
      $sql = "INSERT INTO attachment (TaskID, filename, filetype, filesize, filepath, Datesubmitted, Timesubmitted) 
              VALUES ('$TaskID', '$filename', '$filetype', $filesize, '$target_path', '$Datesubmitted1', '$Timesubmitted')";
      mysqli_query($conn, $sql);
      header("location:taskcheck.php?success=successfully%20submitted"); 
    } else if (empty($_FILES['filename']['filetype'])) {
       header('location:taskcheck.php?error=No file uploaded');
    }
  }
?>
