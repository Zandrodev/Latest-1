<?php
session_start();
$UserID = $_SESSION['UserID'];
$host = "localhost";
$username = "root";
$password = "";
$dbname = "demologin";

$conn = mysqli_connect($host,$username,$password,$dbname);

// Check if the connection was successful
if (!$conn) {
die('Database connection failed: ' . mysqli_connect_error());
}
// Query the database for tasks assigned to the logged-in user
$sql = "SELECT * FROM leaverequest WHERE UserID = '$UserID'";
if(isset($_GET['types'])) {
  $types = $_GET['types'];
  $sql .= " AND Type IN ('" . implode("', '", $types) . "')";
}
if(isset($_GET['status'])) {
  $status = $_GET['status'];
  $sql .= " AND Status IN ('" . implode("', '", $status) . "')";
}
$sql .= " ORDER BY CASE Status 
          WHEN 'Rejected' THEN 1
          WHEN 'Pending' THEN 2
          WHEN 'Approved' THEN 3
          ELSE 4
        END";

$result = mysqli_query($conn, $sql);

// Check if the query was successful
if (!$result) {
die('Query failed: ' . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <title>Leave Requests</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="fileleavecheck.css">
    <link href='Admin/boxicons-2.1.4/css/boxicons.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <?php 
 if (!isset($_SESSION['UserID'])) {
  // User is not logged in
 
  $is_logged_in = false;

} else {
  // User is logged in
  $is_logged_in = true;
}
?>
<script>
var isLoggedIn = <?php echo $is_logged_in ? 'true' : 'false'; ?>;
if (!isLoggedIn) {
  alert("Please log in to access this page.");
 window.location ="loginpage.php";
}
</script>
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <div class="logo_name">
          <img class="Images" src="img/est-transparent.png">
      </div>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
        <a href="dashemployee.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
     <li>
       <a href="Atten.php">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <span class="tooltip">Attendance</span>
     </li>
     <li>
       <a href="Taskcheck.php">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Task Check</span>
       </a>
       <span class="tooltip">Task Check</span>
     </li>
     <li>
       <a href="fileleavecheck.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
       <span class="tooltip">Filing Leave</span>
     </li>
     <li>
     <li class="profile">
         <div class="profile-details">
         <div class="name_job">
             <div class="name"><?php
               
               echo " " .$_SESSION['Name']
               ?></div>
             <div class="job"><?php
               echo " " .$_SESSION['Department']
               ?></div>
           </div>
         </div>
         <form action="logout.php" method="POST">

         <button type="submit" class='bx bx-log-out' id="log_out" ></i>
           </form>
     </li>
    </ul>
  </div>
  <div class="topd">
        <h1>University of Cebu Banilad<h1>
</div>
  <div class="navbar">
  <div class="pic">
          <img class="pic" src="../img/est-transparent.png">
      </div>
  <div class="dropdown">
    <button class="dropbtn">  
      <i class="bx bx-menu"></i>
    </button>
    <div class="dropdown-content">
    <a href="employeelist.php">
         <i class='bx bx-user' ></i>
         <span class="links_name">Employees List</span>
</a>
<a href="atdevelop.php">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <a href="fileleavecheck.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
    </div>
  </div>
</div>
  <section class="home-section">
  <div class="text">
  <?php if (isset($_GET['error'])) { ?>
                  <p class= "error"><?php echo $_GET['error']; ?></p>
                <?php } ?>
   <div class="head">
    <h2>Leave Request</h2>
</div>  
  <div class="filter">
    <form method="get" action="">
  
  <div>
  <label><input type="checkbox" name="types[]" id="personal" value="personal"> Approved</label><br>
</div>
  <div>
  <label><input type="checkbox" name="status[]" id="rejected" value="Rejected"> Rejected</label><br>
</div>
<div>
<input type="submit" value="Filter">
</div>
</form>
</div>
<div class ="addtask">
  <a href="fileleave.php" >File Leave</a>
</div>
    <div class="add">
      
      <style>
    .success {
                    background-color: none;
                    color: red;
                    width:55%;
                    font-size: 18px;
                    padding: 5px;
                    position: absolute; top: 5%; left: 55.5%;
                  }
                  .error {
                    background-color: none;
                    color: red;
                    width:55%;
                    font-size: 18px;
                    padding: 5px;
                    position: absolute; top: 3.5%; left: 55.5%;
                  }
                  </style>
                  <?php if (isset($_GET['success'])) { ?>
                  <p class= "error2"><?php echo $_GET['success']; ?></p>
                <?php } ?>
    
   
    <?php
    
    if(mysqli_num_rows($result) == 0) {
      echo "<p style= 'margin-left: 40%;'>No task at the moment.</p>";
    } else {
// Display the results in an HTML table
while ($row = mysqli_fetch_assoc($result)) {
  $class = '';
  switch ($row['Type']) {
    case 'urgent':
      $class = 'urgent';
      break;
    case 'personal':
      $class = 'personal';
      break;
    case 'normal':
      $class = 'normal';
      break;
    default:
      $class = 'rejected';
      break;
  }
  echo "<div class='taskwrap $class'>";
  echo '<h3>' . $row['Type'] . '</h3>';
  echo '<div class="desc">' . $row['Reason'] . '</div>';
  echo '<div class="start">Start Date: ' . $row['StartDate'] . '</div>';
  echo '<div class="end">End Date:  ' . $row['EndDate'] . '</div>';




  if ($row['Status'] == 'Pending') {
    echo '<div class="stat">' . $row['Status'] . '</div>';
    echo '<div class="img">';
    echo '<a href="fileleaveview.php?requestID=' . $row['requestID'] . '"">View Request</a>';
    echo '</div>'; 
    echo  '<img class="pic" src="img/attachments.png">';
  }elseif ($row['Status'] == 'Approved'){
    echo '<div class="stat" style="background-color:green; color: white;">' . $row['Status'] . '</div>';
    echo '<div class="img">';
    echo '<a href="fileleaveview.php?requestID=' . $row['requestID'] . '"">View Request</a>';
    echo '</div>'; 
    echo  '<img class="pic" src="img/attachments.png">';
  }elseif ($row['Status'] == 'Rejected'){
    echo '<div class="stat" style="background-color:red; color: white;">' . $row['Status'] . '</div>';
    echo '<div class="img">';
    echo '<a href="fileleaveview.php?requestID=' . $row['requestID'] . '"">View Request</a>';
    echo '</div>'; 
    echo  '<img class="pic" src="img/attachments.png">';
  } elseif ($row['Status'] == 'Unfinished'){
    echo '<div class="DL"><label>Deadline: ' . $row['Deadline'] . '</label></div>';
    echo '<input type="text" class="text" name="text" id="text" placeholder="Type your comment....">';
    echo '<form action="taskupload.php?TaskID=' . $row['TaskID'] . '" method="post" enctype="multipart/form-data">';
    echo '<input type="file" class="attach" name="attachment_file" id="attachments">';
    echo '<input type="submit" class="submit" value="Submit">';
    echo '</form>';
    
  }  
  echo "</div><br><br>";
}
    }

// Close the database connection
mysqli_close($conn);
?>
</div>
  </section>
  <script src="scripttest.js"></script>
</body>
</html>
