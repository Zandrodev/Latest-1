 // Get the video element and the text element
 var video = document.getElementById("myVideo");
 var text = document.querySelector(".text");
 var head = document.querySelector('.header');

 // Hide the video initially
 video.style.display = "none";

 // Show the text initially
 text.style.display = "";
 head.style.display ="";

 // After 30 seconds, hide the text and show the video
 setTimeout(function() {
   text.style.display = "none";
    head.style.display ="none";
   video.style.display = "block";
   video.play();
 }, 10000);