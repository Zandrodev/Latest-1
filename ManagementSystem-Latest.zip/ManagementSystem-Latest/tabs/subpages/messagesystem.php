<!DOCTYPE html>
<html>
<head>
	<title>Employee to Admin Message System</title>
</head>
<body>
	<h1>Employee to Admin Message System</h1>

	<!-- Form to send a message -->
	<form method="post" action="send_message.php">
		<label for="receiver_id">Recipient ID:</label>
		<input type="text" name="receiver_id" id="receiver_id"><br><br>

		<label for="message_body">Message:</label><br>
		<textarea name="message_body" id="message_body" rows="4" cols="50"></textarea><br><br>

		<input type="submit" value="Send Message">
	</form>

	<!-- List of conversations for the admin -->
	<h2>Conversations</h2>
  <?php
  $host = "localhost";
  $username = "root";
  $password = "";
  $dbname = "demologin";
  
  $conn = mysqli_connect($host,$username,$password,$dbname);
  
  if ($conn)
  {
	echo "";
  }
  else {
	echo "Connection failed".mysqli_connect_error();
  }

// Retrieve the messages for a conversation
$messageID = 10001;
$sql = "SELECT * FROM messages WHERE messageID = $messageID ORDER BY created_at";
$result = mysqli_query($conn, $sql);

// Display the messages in the HTML structure
echo '<ul>';
while ($row = mysqli_fetch_assoc($result)) {
	$message_id = $row['message_id'];
	$sender_id = $row['sender'];
	$receiver_id = $row['recevier'];
	$message_body = $row['message'];
	$created_at = $row['createdat'];
	$status = $row['status'];

	// Get the name of the sender and receiver
	$sql2 = "SELECT * FROM loginform WHERE UserID = $sender_id OR UserID = $receiver_id";
	$result2 = mysqli_query($conn, $sql2);
	$sender_name = '';
	$receiver_name = '';
	while ($row2 = mysqli_fetch_assoc($result2)) {
		if ($row2['user_id'] == $sender_id) {
			$sender_name = $row2['name'];
		} else {
			$receiver_name = $row2['name'];
		}
	}

	// Output the message
	echo '<li>';
	echo '<strong>' . $sender_name . ':</strong>';
	echo '<p>' . $message_body . '</p>';
	echo '<small>' . $created_at . '</small>';
	echo '</li>';
}
echo '</ul>';
?>
</body>
</html>