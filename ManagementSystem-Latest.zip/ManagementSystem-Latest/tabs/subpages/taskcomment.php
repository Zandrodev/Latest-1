<?php
  // save feedback to database (assuming you have a MySQL database set up)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "demologin";

    // create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    $TaskID= $_GET['TaskID']; // replace with the actual task ID
    $comment = mysqli_real_escape_string($conn, $_POST['comment']); // replace with the actual comment text

// build the SQL query to update the comment field of the task with the given ID
$sql = "UPDATE task SET comment = '$comment' WHERE TaskID = $TaskID";

// execute the query
if ($conn->query($sql) === TRUE) {
  echo "Comment updated successfully";
} else {
  echo "Error updating comment: " . $conn->error;
}
    // display success message
    header("Location: taskcheck.php");
?>