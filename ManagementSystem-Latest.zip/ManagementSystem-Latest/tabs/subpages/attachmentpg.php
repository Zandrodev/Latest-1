<?php 
$host = "localhost";
      $username = "root";
      $password = "";
      $dbname = "demologin";
      
      $conn = mysqli_connect($host,$username,$password,$dbname);
      
      // Check if the connection was successful
      if (!$conn) {
      die('Database connection failed: ' . mysqli_connect_error());

      }
      $TaskID = $_GET['TaskID'];
$task_query = "SELECT Ontime, comment, title, description, Deadline, UserID, Status FROM task WHERE TaskID = $TaskID";
$task_result = mysqli_query($conn, $task_query);
$task = mysqli_fetch_assoc($task_result);

// Query the user table to get the assigned user's information
$user_query = "SELECT Name FROM loginform WHERE UserID = " . $task['UserID'];
$user_result = mysqli_query($conn, $user_query);
$user = mysqli_fetch_assoc($user_result);

// Query the attachment table to get the attachments for the task
$attachment_query = "SELECT filename, attachmentID, filepath, Datesubmitted, Timesubmitted FROM attachment WHERE TaskID = $TaskID";
$attachment_result = mysqli_query($conn, $attachment_query);
$attach = mysqli_fetch_assoc($attachment_result);

$feedback_query = "SELECT comment, rating FROM taskfeedback WHERE TaskID = $TaskID";
$feedback_result = mysqli_query($conn, $feedback_query);
$feedback = mysqli_fetch_assoc($feedback_result);

$status = $task['Status'];      
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <title>Task</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="attachmentpg.css">
    <link href='admin/boxicons-2.1.4/css/boxicons.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <div class="logo_name">
          <img class="Images" src="img/est-transparent.png">
      </div>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
        <a href="dashemployee.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
     <li>
       <a href="Atten.php">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <span class="tooltip">Attendance</span>
     </li>
     <li>
       <a href="Taskcheck.php">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Task Check</span>
       </a>
       <span class="tooltip">Task Check</span>
     </li>
     <li>
       <a href="fileleavecheck.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
       <span class="tooltip">Filing Leave</span>
     </li>
     <li>
     <li class="profile">
         <div class="profile-details">
         <div class="name_job">
         <div class="name"><?php
         session_start();
               echo " " .$_SESSION['Name']
               ?></div>
             <div class="job"><?php
               echo " " .$_SESSION['Department']
               ?></div>
         </div>
         <form action="logout.php" method="POST">

         <button type="submit" class='bx bx-log-out' id="log_out" ></i>
           </form>
     </li>
    </ul>
  </div>
  <div class="topd">
        <h1>University of Cebu Banilad<h1>
</div>
  <div class="navbar">
  <div class="pic">
          <img class="pic" src="img/est-transparent.png">
      </div>
  <div class="dropdown">
    <button class="dropbtn">  
      <i class="bx bx-menu"></i>
    </button>
    <div class="dropdown-content">
    <a href="employeelist.php">
         <i class='bx bx-user' ></i>
         <span class="links_name">Employees List</span>
</a>
<a href="attendancerecord.php">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <a href="Leave.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
    </div>
  </div>
</div>
  <section class="home-section">
  <div class="text">
    <div class="head">
      <div><a href="taskcheck.php"> Back to Task Check</a></div>
      <?php
      if ($status == "Pending") {
    // display this form if status is finished
    echo '<form method="POST">';
echo '  <button type="submit" name="approval_status" value="approved" class="approve">PENDING</button>';
echo '</form>';
} elseif ($status == "Approved") {
   echo '<div style="background-color:green; color: white; border-radius: 25px; width: 100%; text-align: center; padding: 9px;">Task has been approved</div>';
   
}elseif ($status == "Rejected") {
  echo '<div style="background-color:red; border-radius: 25px; width: 100%; text-align: center; padding: 9px;">Task has been rejected</div>';
  
}  else{
  echo "Task is unfinished.";
}
?>
</div>
    <div class= "top">
        <div>

        <div><?php echo "" . $task['title'] . ""; ?></div>
        </div> 
        <div><?php echo "" . $task['description'] . ""; ?></div>
        
        <div>
        <div>Attachment:</div>
        <div><img src="img/attachments.png"></div>
        <div><?php if (!empty($attach['filename']) && !empty($attach['attachmentID'])) {
 echo "<a href='admin/download.php?attachmentid=" . $attach['attachmentID'] . "'>" . $attach['filename'] . "</a>";
 
} else {
  echo "No file";
} ?></div>
</div>
<div>
<div>
    <?php

// Assuming you have variables $attach['Timesubmitted'] and $attach['Datesubmitted']
if(!empty($attach['Timesubmitted']) && !empty($attach['Datesubmitted'])) {
  echo 'Submitted on: ' . $attach['Timesubmitted'] . ' (' . $attach['Datesubmitted'] . ')';
} else {
  echo "No submittion";
}
?>
</div>
<?php
if ($task['Ontime'] == 'Late' && strtotime(date('Y-m-d')) > strtotime($task['Deadline'])) {
    echo '<div class="late" style="color:red;">Late submission!</div>';
    
  }
  ?>
       <div> <?php echo "Deadline:" . $task['Deadline'] . "";
?></div>
        </div>
        <div><?php echo "Comment: " . $task['comment'] . ""; ?></div> 
</div>
<div class="bottom"> 
  <div>
  <?php
    if (!$feedback) {
      echo "No feedback.";
    } else {
      $data = $feedback['rating'];
      if ($data == 1) {
        echo "Feedback: ★";
      } else if ($data == 2) {
        echo "Feedback: ★★";
      } else if ($data == 3) {
        echo "Feedback: ★★★";
      } else if ($data == 4) {
        echo "Feedback: ★★★★";
      } else if ($data == 5) {
        echo "Feedback: ★★★★★";
      } else {
        echo "Unknown data.";
      }
    }
    ?>
</div>
 
  <div><?php if (empty($feedback['comment'])) {
  echo "No comment.";
} else {
  echo "" . $feedback['comment'] . "";
} ?></div>
    </div>
</div>
</div>
  </section>
  <script src="scripttest.js"></script>
</body>
</html>
