<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "demologin";

$conn = mysqli_connect($host,$username,$password,$dbname);

if ($conn)
{
  echo "";
}
else {
  echo "Connection failed".mysqli_connect_error();
}

session_start();
//Submit leave request
if(isset($_POST['submit'])) {
    // Get employee ID from session
    $UserID = $_SESSION['UserID'];
    // Get leave request data from form inputs
    $type = $_POST['Type'];
    $reason = $_POST['Reason'];
    $start_date = $_POST['StartDate'];
    $end_date = $_POST['EndDate'];
    
    // Get file data from uploaded file
    $attachment_name = $_FILES['attachment']['name'];
    $attachment_tmp_name = $_FILES['attachment']['tmp_name'];
    $attachment_dest_path = 'admin/leaveattach/' . $attachment_name;
    
    // Move uploaded file to server directory
    if(move_uploaded_file($attachment_tmp_name, $attachment_dest_path)) {
        // Insert leave request data into leave_request table
        $sql = "INSERT INTO leaverequest (UserID, Type, Reason, StartDate, EndDate, Status) VALUES ('$UserID', '$type', '$reason', '$start_date', '$end_date', 'Pending')";
        
        if(mysqli_query($conn, $sql)) {
            // Get RequestID of newly inserted row
            $requestID = mysqli_insert_id($conn);
            
            // Insert attachment data into leave_attachment table
            $sql = "INSERT INTO leaveattachment (requestID, attachmentPath, attachmentName) VALUES ('$requestID', '$attachment_dest_path', '$attachment_name')";
            
            if(mysqli_query($conn, $sql)) {
                header('location:fileleavecheck.php');
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "Error uploading attachment";
    }
}
?>