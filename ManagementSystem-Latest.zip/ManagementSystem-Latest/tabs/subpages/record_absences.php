<?php
include("Admin/connection.php");
$current_date = date("Y-m-d");

// Query the database for employees who have not recorded attendance for today
$sql = "SELECT * FROM Loginform WHERE UserID NOT IN (SELECT UserID FROM attendance WHERE date = '$current_date')";
$result = mysqli_query($conn, $sql);

// Loop through the results and mark each employee as absent if they have no attendance record for today
while ($row = mysqli_fetch_assoc($result)) {
    $employee_id = $row['UserID'];
    $Name = $row['Name'];
    $Department = $row['Department'];
    $sql = "SELECT * FROM attendance WHERE UserID = '$employee_id' AND date = '$current_date'";
    $result2 = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result2) == 0) {
        $sql = "INSERT INTO attendance (UserID, date, status, Name, Department) VALUES ('$employee_id', '$current_date', 'Absent', '$Name', '$Department')";
        mysqli_query($conn, $sql);
    }
}

// Close the database connection
mysqli_close($conn);

?>