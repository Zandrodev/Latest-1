<?php
// Connect to the database
$host = "localhost";
$username = "root";
$password = "";
$dbname = "demologin";

$db = mysqli_connect($host, $username, $password, $dbname);

if (!$db) {
  echo "Connection failed" . mysqli_connect_error();
}

// Get email address from form submission
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Include PHPMailer autoload file
require_once 'assets/PHPMailer/src/PHPMailer.php';
require_once 'assets/PHPMailer/src/SMTP.php';
require_once 'assets/PHPMailer/src/Exception.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Get the recipient's email address from the form
    $recipient_email_address = $_POST['Email'];

    // Check if the email exists in the database
    $sql = "SELECT * FROM loginform WHERE Email='$recipient_email_address'";
    $result = mysqli_query($db, $sql);

    if (mysqli_num_rows($result) == 0) {
      $errors['Email'] = 'Invalid Email Address';
    } else {

        // Generate a random code
        $Token = substr(md5(uniqid()), 0, 8);

        // Store the code in the database
        $sql = "INSERT INTO resettokens (Email, Token) VALUES ('$recipient_email_address', '$Token')";
        mysqli_query($db, $sql);

        // Create a new PHPMailer instance
        $mail = new PHPMailer(true);

        try {
            // SMTP settings for Gmail
            $mail->isSMTP();
            $mail->SMTPDebug = 0;
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = 'tls';
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 587;
            $mail->Username = 'antpayton12@gmail.com';
            $mail->Password = 'osqzcqwueevpeome';

            // Set email content
            $mail->setFrom('antpayton12@gmail.com', 'UCB Employee System Tracker');
            $mail->addAddress($recipient_email_address);
            $mail->Subject = 'Forgot Password';
            $mail->Body = 'Use this verification code to reset your password: ' . $Token;

            session_start();
            $mail->send();
            $message = "We've sent a verification code to your Email $recipient_email_address";

            $_SESSION['message'] = $message;
            header('location:forgotverify.php');
        } catch (Exception $e) {
            echo 'Message could not be sent. Mailer Error: ' . $mail->ErrorInfo;
        }
    }
}
?>
