<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <title>Dashboard</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="dashemployee.css">
    <link rel="stylesheet" href="./assets/css/chat.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="./assets/css/typing.css">
    <link href='Admin/boxicons-2.1.4/css/boxicons.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <?php 
include("auth.php");
?>

   </head>
<body>

  <div class="sidebar">
    <div class="logo-details">
      <div class="logo_name">
          <img class="Images" src="img/est-transparent.png">
      </div>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
        <a href="dashemployee.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
    
     <li>
       <a href="atten.php">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <span class="tooltip">Attendance</span>
     </li>
     <li>
       <a href="taskcheck.php">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Task Check</span>
       </a>
       <span class="tooltip">Task Check</span>
     </li>
     <li>
       <a href="fileleavecheck.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
       <span class="tooltip">Filing Leave</span>
     </li>
     <li>
     <li class="profile">
         <div class="profile-details">
           <!--<img src="profile.jpg" alt="profileImg">-->
           <div class="name_job">
             <div class="name"><?php
               echo " " .$_SESSION['Name']
               ?></div>
             <div class="job"><?php
               echo " " .$_SESSION['Department']
               ?></div>
           </div>
         </div>
         <form action="logout.php" method="POST">

         <button type="submit" class='bx bx-log-out' id="log_out" ></i>
           </form>
     </li>
    </ul>
  </div>
  <div class="topd">
        <h1>University of Cebu Banilad</h1>
</div>
  <section class="home-section">
      <div class="text">
        <div class="upleft">
          <div class="up">
          <p> <?php
               echo "Welcome Back, " .$_SESSION['Name']
               ?></p>
          <h4>Get your day started!</h4>
          <span id="clock"></span>
</div>
</div>
<div class="upright">
  <div class="upr">
  <?php
   $host = 'localhost';
   $user = 'root';
   $password = '';
   $db_name = 'demologin';
 
   $conn = mysqli_connect($host, $user, $password, $db_name);
   
   
   // Check connection
   if ($conn->connect_error) {
       die("Connection failed: " . $conn->connect_error);
   }
$UserID = $_SESSION['UserID'];

// SQL query to retrieve task counts by status
$sql = "SELECT CONCAT(COUNT(IF(task.Status = 'Rejected', 1, NULL)), ' Rejected Tasks') AS RejectedCount,
               CONCAT(COUNT(IF(task.Status = 'Unfinished', 1, NULL)), ' Unfinished Tasks') AS UnfinishedCount,
               CONCAT(COUNT(IF(task.Status = 'Pending', 1, NULL)), ' Pending tasks') AS PendingCount
        FROM task
        WHERE task.UserID = '$UserID'";


// Execute the SQL query and store the result set in a variable
$result1 = $conn->query($sql);

// Check for errors during the query execution
if (!$result1) {
    die("Query failed: " . $conn->error);
}

// Display the task counts for the current user
if ($row1 = $result1->fetch_assoc()) {
    echo "<div style='display: flex; flex-direction: row; gap: 10px;'><p style ='background-color: orange; padding: 12px; height: 5%;  border-radius: 25px;'></p>" . $row1["UnfinishedCount"] . "</div>";
    echo "<div style='display: flex; flex-direction: row; gap: 10px;'><p style ='background-color: red; padding: 12px; height: 5%;  border-radius: 25px;'></p>" . $row1["RejectedCount"] . "</div>";
    echo "<div style='display: flex; flex-direction: row; gap: 10px;'><p style ='background-color: gray; padding: 12px; height: 5%;  border-radius: 25px;'></p>" . $row1["PendingCount"] . "</div>";
}

// Close the database connection
$conn->close();

?>
  
</div>
</div>
<div class="middle">
  <div>
  <div>Calendar</div>
</div>
</div>
<div class="downright">
  <div>
  <label>Status</label>
  <div>Present</div>
</div>
</div>
<div class="downleft">
<table>
  <thead>
<tr>
  <th>Title</th>
  <th>Status</th>
  <th>Date</th>
  <th>Deadline</th>
</tr>
</thead>
<?php
if(isset($_SESSION['UserID'])) {

  // Get the UserID of the logged-in user
  $UserID = $_SESSION['UserID'];
  
  $host = 'localhost';
  $user = 'root';
  $password = '';
  $db_name = 'demologin';

  $conn = mysqli_connect($host, $user, $password, $db_name);
  
  // Check connection
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
  // Connect to the database
  $sql ="SELECT * FROM task WHERE UserID = $UserID";



       $sql .= " ORDER BY CASE Status 
          WHEN 'Unfinished' THEN 1
          WHEN 'Rejected' THEN 2
          WHEN 'Pending' THEN 3
          WHEN 'Approved' THEN 4
          ELSE 5
        END";


// Execute the SQL query and store the result set in a variable
$result1 = $conn->query($sql);
  // Query the task table for all tasks associated with the user
  $result = mysqli_query($conn, $sql);
  // Display the tasks in a table
  if(mysqli_num_rows($result) == 0) {
    echo "<td>No task found.</td>";
  } else {

  while($row = mysqli_fetch_array($result)) {
    echo "<tbody><tr><td>" . $row['Title'] . "</td><td>" . $row['Status'] . "</td><td>" . $row['date'] . "</td><td>" . $row['Deadline'] . "</td></tr></tbody>";
  }
  echo "</table>";

  // Close the database connection
  mysqli_close($conn);

}
}
?>

</div>
</div>
  </section>
  <script src="scripttest.js"></script>
</body>
</html>
