<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <title>Dashboard</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="fileleave.css">
    <link href='Admin/boxicons-2.1.4/css/boxicons.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">

     <?php 
include("auth.php");
?>

   </head>
<body>

  <div class="sidebar">
    <div class="logo-details">
      <div class="logo_name">
          <img class="Images" src="img/est-transparent.png">
      </div>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
        <a href="dashemployee.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
    
     <li>
       <a href="atten.php">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <span class="tooltip">Messages</span>
     </li>
     <li>
       <a href="taskcheck.php">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Task Check</span>
       </a>
       <span class="tooltip">Analytics</span>
     </li>
     <li>
       <a href="fileleavecheck.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
       <span class="tooltip">Files</span>
     </li>
     <li>
     <li class="profile">
         <div class="profile-details">
           <!--<img src="profile.jpg" alt="profileImg">-->
           <div class="name_job">
             <div class="name"><?php
               echo " " .$_SESSION['Name']
               ?></div>
             <div class="job"><?php
               echo " " .$_SESSION['Department']
               ?></div>
           </div>
         </div>
         <form action="logout.php" method="POST">

         <button type="submit" class='bx bx-log-out' id="log_out" ></i>
           </form>
     </li>
    </ul>
  </div>
  <div class="topd">
        <h1>University of Cebu Banilad<h1>
</div>
  <section class="home-section">
      <div class="text">
      <div class="top">
        <div>
            <img src ="img/add.png">
            <div>Filing Leave</div>
</div>
<form method="post" action="fileleavedb.php" enctype="multipart/form-data">
    <div>
    <div>
    <label>Type:</label>
    <select name="Type" style="width: 173px; background-color: #D9D9D9; border: solid 1px black;" required>
        <option value="">Select a type</option>
        <option value="Sick Leave">Sick Leave</option>
        <option value="Maternity/Paternity Leave">Maternity/Paternity Leave</option>
        <option value="Emergency Leave">Emergency Leave</option>
        <option value="Vacation Leave">Vacation Leave</option>
        <option value="Bereavement Leave">Bereavement Leave</option>
        <option value="Compensatory Leave">Compensatory Leave</option>
    </select>
    </div>
    <div>
    <label>Reason:</label>
    <input type="text" name="Reason"></input>
    </div>
    <div>
    <label>Start Date:</label>
    <input type="date" class="startdate" name="StartDate" required>
    </div>
    <div>
    <label>End Date:</label>
    <input type="date" class="endate" name="EndDate" required>
    </div>
</div>
<div>
    <div>
    <input type="file" name="attachment"></input>
    </div>
    <div>
    <input type="submit" name="submit"> </input>
    </div>
</div>
</form>
</div>
</div>
  </section>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script src="scripttest.js"></script>
</body>
</html>
