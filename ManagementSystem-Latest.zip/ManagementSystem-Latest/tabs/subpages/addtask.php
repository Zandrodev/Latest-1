<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "demologin";

$conn = mysqli_connect($host,$username,$password,$dbname);
session_start();
// Get the user ID from the URL parameter
$UserID = $_SESSION['UserID'];

// Query the database to get the user information
$query = "SELECT * FROM loginform WHERE UserID = $UserID";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);



// Display the user information
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <title>Assign Task</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="addtask.css">
    <link href='admin/boxicons-2.1.4/css/boxicons.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <div class="logo_name">
          <img class="Images" src="img/est-transparent.png">
      </div>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
        <a href="dashemployee.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
      <li>
       <a href="attendance.php">
         <i class='bx bx-user' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <span class="tooltip">Attendance</span>
     </li>
     <li>
       <a href="Taskcheck.php">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Task Check</span>
       </a>
       <span class="tooltip">Task Check</span>
     </li>
     <li>
       <a href="fileleave.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
       <span class="tooltip">Files</span>
     </li>
     <li>

     <li class="profile">
         <div class="profile-details">
           <!--<img src="profile.jpg" alt="profileImg">-->
           <div class="name_job">
           <div class="name"><?php
               echo " " .$_SESSION['Name']
               ?></div>
             <div class="job"><?php
               echo " " .$_SESSION['Department']
               ?></div>
         </div>
         <form action="logout.php" method="POST">

         <button type="submit" class='bx bx-log-out' id="log_out" ></i>
           </form>
     </li>
    </ul>
  </div>
  <div class="topd">
        <h1>University of Cebu Banilad<h1>
</div>
  <div class="navbar">
  <div class="pic">
          <img class="pic" src="../img/est-transparent.png">
      </div>
  <div class="dropdown">
    <button class="dropbtn">  
      <i class="bx bx-menu"></i>
    </button>
    <div class="dropdown-content">
    <a href="employeelist.php">
         <i class='bx bx-user' ></i>
         <span class="links_name">Employees List</span>
</a>
<a href="atdevelop.php">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <a href="leaveadmin.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
    </div>
  </div>
</div>
  <section class="home-section">
  <div class="text">
    <div>
    <h2> Assign New Task</h2>
</div>
    <form method="post" action="addtaskdb.php?UserID=<?php echo $_SESSION['UserID']; ?>">
        <div>
        <label>Task Title:</label>
        <input type="text" name="title" required>
</div>
<div>
        <label>Description:</label>
    <textarea name="description" required></textarea>
</div>
<div>
    <label for="deadline">Deadline:</label>
    <input type="date" name="deadline" required>
</div>
<div>
    <label for="type">Type:</label>
    <select name="type" required>
        <option value="">Select a type</option>
        <option value="urgent">Urgent</option>
        <option value="personal">Personal</option>
        <option value="normal">Normal</option>
    </select>
</div>
  <div>
    <input type="submit" name="submit" value="Save">
</div>
  </form>
</div>
</div>
  </section>
  <script src="scripttest.js"></script>
</body>
</html>
