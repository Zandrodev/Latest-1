<?php
// Start session
$host = "localhost";
 $username = "root";
 $password = "";
 $dbname = "demologin";
 
 $conn = mysqli_connect($host,$username,$password,$dbname);
 
 if ($conn)
 {
   echo "";
 }
 else {
   echo "Connection failed".mysqli_connect_error();
 } 
// Get input values from the form
$message_body = $_POST['message_body'];
$receiver_id = $_POST['receiver_id'];

// Validate input
if (empty($message_body) || empty($receiver_id)) {
  // Display error message
  die('Please enter a message and recipient.');
}

// Insert message into database
$sql = "INSERT INTO messages (sender_id, receiver_id, message_body, created_at, status) 
        VALUES ($employee_id, $receiver_id, '$message_body', NOW(), 'unread')";
$result = mysqli_query($conn, $sql);

if (!$result) {
  // Display error message
  die('Error: ' . mysqli_error($conn));
} else {
  // Display success message
  echo 'Message sent.';
}