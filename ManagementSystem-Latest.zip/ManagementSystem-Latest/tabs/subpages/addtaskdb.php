<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "demologin";
$conn = mysqli_connect($host, $username, $password, $dbname);
date_default_timezone_set('Asia/Manila');
// Check if the connection is successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
session_start();
// Check if the form has been submitted
if (isset($_POST['submit'])) {
    // Retrieve the task details from the form
    
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $deadline = mysqli_real_escape_string($conn, $_POST['deadline']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $date = Date('y-m-d');
    $UserID = $_SESSION['UserID'];
    // Insert the task details into the tasks table in the database
    $sql = "INSERT INTO task (UserID, title, description,date, deadline, type) VALUES ( '$UserID', '$title', '$description','$date', '$deadline', '$type')";
    if (mysqli_query($conn, $sql)) {
        header("Location: taskcheck.php?error=Task added");
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
.table-wrapper{
  max-height: 400px;
  max-width: 700px;
  overflow: auto;
  border-radius: 5px;
  border-bottom: solid;
}
.home-section .text .table{
  grid-area: table;
  background-color: none;
  height: 10%;
  border-radius: 5%;
}
.home-section .text .table table{
border-collapse: collapse;
font-size: 19px;
min-width: 200px;
background-color: white;
}