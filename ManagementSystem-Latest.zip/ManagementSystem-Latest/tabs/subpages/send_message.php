<?php 
 $host = "localhost";
 $username = "root";
 $password = "";
 $dbname = "demologin";
 
 $conn = mysqli_connect($host,$username,$password,$dbname);
 
 if ($conn)
 {
   echo "";
 }
 else {
   echo "Connection failed".mysqli_connect_error();
 }
 // Start session
 session_start();
 
 // Get form data
 $recipient = mysqli_real_escape_string($conn, $_POST['recipient']);
 $message = mysqli_real_escape_string($conn, $_POST['message']);
 
 // Insert message into database
 $query = "INSERT INTO messages (sender, recipient, message) VALUES ('".$_SESSION['Name']."', '$recipient', '$message')";
 mysqli_query($conn, $query);
 
 // Redirect back to messaging interface
 header('Location: messagesystem.php');
 exit();