<?php 
   session_start();
   if (!isset($_SESSION['UserID'])) {
    // User is not logged in
   
    $is_logged_in = false;
  
} else {
    // User is logged in
    $is_logged_in = true;
}
?>
<script>
var isLoggedIn = <?php echo $is_logged_in ? 'true' : 'false'; ?>;
if (!isLoggedIn) {
    alert("Please log in to access this page.");
   window.location ="loginpage.php";
}
</script>