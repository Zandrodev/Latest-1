<?php
session_start();
$UserID = $_SESSION['UserID'];
$host = "localhost";
$username = "root";
$password = "";
$dbname = "demologin";

$conn = mysqli_connect($host,$username,$password,$dbname);

// Check if the connection was successful
if (!$conn) {
die('Database connection failed: ' . mysqli_connect_error());
}
// Query the database for tasks assigned to the logged-in user
$sql = "SELECT * FROM task WHERE UserID = '$UserID'";
if(isset($_GET['types'])) {
  $types = $_GET['types'];
  $sql .= " AND Type IN ('" . implode("', '", $types) . "')";
}
if(isset($_GET['status'])) {
  $status = $_GET['status'];
  $sql .= " AND Status IN ('" . implode("', '", $status) . "')";
}
$sql .= " ORDER BY CASE Status 
          WHEN 'Unfinished' THEN 1
          WHEN 'Rejected' THEN 2
          WHEN 'Pending' THEN 3
          WHEN 'Approved' THEN 4
          ELSE 5
        END";

$result = mysqli_query($conn, $sql);

// Check if the query was successful
if (!$result) {
die('Query failed: ' . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <title>Task Check</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="taskcheck.css">
    <link href='Admin/boxicons-2.1.4/css/boxicons.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
 <?php 
 if (!isset($_SESSION['UserID'])) {
  // User is not logged in
 
  $is_logged_in = false;

} else {
  // User is logged in
  $is_logged_in = true;
}
?>
<script>
var isLoggedIn = <?php echo $is_logged_in ? 'true' : 'false'; ?>;
if (!isLoggedIn) {
  alert("Please log in to access this page.");
 window.location ="loginpage.php";
}
</script>
   </head>
<body>
  <div class="sidebar">
    <div class="logo-details">
      <div class="logo_name">
          <img class="Images" src="img/est-transparent.png">
      </div>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
        <a href="dashemployee.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
     <li>
       <a href="Atten.php">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <span class="tooltip">Attendance</span>
     </li>
     <li>
       <a href="Taskcheck.php">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Task Check</span>
       </a>
       <span class="tooltip">Task Check</span>
     </li>
     <li>
       <a href="fileleavecheck.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
       <span class="tooltip">Filing Leave</span>
     </li>
     <li>
     <li class="profile">
         <div class="profile-details">
         <div class="name_job">
             <div class="name"><?php
               
               echo " " .$_SESSION['Name']
               ?></div>
             <div class="job"><?php
               echo " " .$_SESSION['Department']
               ?></div>
           </div>
         </div>
         <form action="logout.php" method="POST">

         <button type="submit" class='bx bx-log-out' id="log_out" ></i>
           </form>
     </li>
    </ul>
  </div>
  <div class="topd">
        <h1>University of Cebu Banilad<h1>
</div>
  <div class="navbar">
  <div class="pic">
          <img class="pic" src="../img/est-transparent.png">
      </div>
  <div class="dropdown">
    <button class="dropbtn">  
      <i class="bx bx-menu"></i>
    </button>
    <div class="dropdown-content">
    <a href="employeelist.php">
         <i class='bx bx-user' ></i>
         <span class="links_name">Employees List</span>
</a>
<a href="atdevelop.php">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <a href="fileleavecheck.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
    </div>
  </div>
</div>
  <section class="home-section">
  <div class="text">
   <div class="head">
    <h2>Task Check</h2>
</div>  
  <div class="filter">
    <form method="get" action="">
   <div>
  <label><input type="checkbox" name="types[]" id="urgent" value="urgent"> Urgent</label><br>
</div>
  <div>
  <label><input type="checkbox" name="types[]" id="personal" value="personal"> Personal</label><br>
</div>
  <div>
  <label><input type="checkbox" name="status[]" id="rejected" value="Rejected"> Rejected</label><br>
</div>
<div>
<input type="submit" value="Filter">
</div>
  <div>
  <label><input type="checkbox" name="status[]" id="approved" value="Approved"> Approved</label><br>
</div>
  <div>
  <label><input type="checkbox" name="status[]" id="finished" value="Pending"> Pending</label><br>
</div>
  <div>
  <label><input type="checkbox" name="types[]" id="normal" value="normal"> Normal</label><br>
</div>

</form>
</div>
<div class ="addtask">
  <a href="addtask.php" >Add New Task</a>
</div>
    <div class="add">
    
   
    <?php
    if (isset($_GET['error'])) {
      echo '<div style ="margin-left: 89%; color: orange;">' . $_GET['error'] . '</div>';
    }
    if(mysqli_num_rows($result) == 0) {
      echo "<p style= 'margin-left: 40%;'>No task at the moment.</p>";
    } else {

// Display the results in an HTML table
while ($row = mysqli_fetch_assoc($result)) {
  $class = '';
  switch ($row['Type']) {
    case 'urgent':
      $class = 'urgent';
      break;
    case 'personal':
      $class = 'personal';
      break;
    case 'normal':
      $class = 'normal';
      break;
    default:
      $class = 'rejected';
      break;
  }
  if ($row['Status'] == 'Unfinished' && strtotime(date('Y-m-d')) > strtotime($row['Deadline'])) {
    echo '<div style="color:red;">Late submission!</div>';
    
  }
  if ($row['Ontime'] == 'Late' && strtotime(date('Y-m-d')) > strtotime($row['Deadline'])) {
    echo '<div style="color:red;">Late submission!</div>';
    
  }
  echo "<div class='taskwrap $class'>";
  echo '<h3>' . $row['Title'] . '</h3>';
  echo '<div class="desc">' . $row['Description'] . '</div>';
  echo '<div class="type">' . $row['Type'] . '</div>';
  echo '<form class="textform" action="taskcomment.php?TaskID=' . $row['TaskID'] . '" method="post" >';
  echo '<input type="text" class="text" name="comment" id="text" placeholder="Type your comment....">';
  echo '</form>';


  if ($row['Status'] == 'Pending') {
    echo '<div class="stat">' . $row['Status'] . '</div>';
    echo '<div class="img">';
    echo '<a href="attachmentpg.php?TaskID=' . $row['TaskID'] . '"">View Task</a>';
    echo '</div>'; 
    echo  '<img class="pic" src="img/attachments.png">';
  }elseif ($row['Status'] == 'Approved'){
    echo '<div class="stat" style="background-color:green; color: white;">' . $row['Status'] . '</div>';
    echo '<div class="img">';
    echo '<a href="attachmentpg.php?TaskID=' . $row['TaskID'] . '"">View Task</a>';
    echo '</div>'; 
    echo  '<img class="pic" src="img/attachments.png">';
  }elseif ($row['Status'] == 'Rejected'){
    echo '<div class="stat" style="background-color:red; color: white;">' . $row['Status'] . '</div>';
    echo '<div class="img">';
    echo '<a href="attachmentpg.php?TaskID=' . $row['TaskID'] . '"">View Task</a>';
    echo '</div>'; 
    echo  '<img class="pic" src="img/attachments.png">';
  } elseif ($row['Status'] == 'Unfinished'){
    echo '<div class="DL"><label>Deadline: ' . $row['Deadline'] . '</label></div>';
    echo '<form action="taskupload.php?TaskID=' . $row['TaskID'] . '" method="post" enctype="multipart/form-data">';
    echo '<input type="file" class="attach" name="attachment_file" id="attachments">';
    echo '<input type="submit" class="submit" value="Submit">';
    echo '</form>';
    
  }  
  echo "</div><br><br>";
}
    }

// Close the database connection
mysqli_close($conn);
?>
</div>
  </section>
  <script src="scripttest.js"></script>
</body>
</html>
