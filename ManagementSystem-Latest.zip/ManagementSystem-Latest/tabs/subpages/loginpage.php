<html lang="en">
    <head>
    <link rel="icon" href="img/trishtain.jpg" type="image/png">
        <link rel="stylesheet" href="logins.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>ETS</title>
    </head>
    <body>
       
    <section>
    <a href="developers.html" style="text-decoration: none; color:white; position:absolute; top: 5%; left: 3%; background-color: black; border-radius: 25px; padding: 15px;">Developers</a>
        <div class="form">
             <div class="login-box">
                <form action="logindb.php" method="POST">
                  <style>
                  .error {
                    background-color: none;
                    color: red;
                    width:70%;
                    padding: 5px;
                    position: absolute; top: 38%; left: 10.5%;
                  }
                  </style>
                  <?php if (isset($_GET['error'])) { ?>
                  <p class= "error"><?php echo $_GET['error']; ?></p>
                <?php } ?>
                    <div class="ets-logo">
                        <img class="Images" src="img/est-transparent.png">
                    </div>
                    <div class="username">
                        <ion-icon name="person-outline"></ion-icon>
                        <input type="username" name="UserID" required="">
                        <label for="">User_ID#</label>
                    </div>
                    <div class="password">
                        <ion-icon name="lock-closed-outline"></ion-icon>
                        <input type="password" name="Password" required="">
                        <label for="">Password</label>
                    </div>
                    <div class="forget">
                       </span> <a href="forgot.php"> Forgot Password?</a></label>
                    </div>
                    <button>Login</button>
                  </form>
                    <div class="register">
                    </div>
                            <div class="icons">
            <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
            <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
        </div>

             </div>
          </div>
        </section>
    </body>
</html>

