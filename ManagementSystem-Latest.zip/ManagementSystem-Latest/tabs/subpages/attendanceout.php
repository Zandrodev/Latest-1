<?php
include("Admin/connection.php");
date_default_timezone_set('Asia/Manila');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();
$UserID = $_SESSION['UserID'];
$current_date = date('Y-m-d');

// Check if user has timein2 data
$query = "SELECT timein2 FROM attendance WHERE UserID = '$UserID' AND Date = '$current_date' AND timein2 IS NOT NULL";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
  // Update the attendance record with the current time and Identify status
  $current_time = date("H:i:s");
  $query = "UPDATE attendance SET timeout2 = '$current_time', Identify = 'Out' WHERE UserID = '$UserID' AND date = '$current_date'";
  $result = mysqli_query($conn, $query);

  if ($result) {
    // Successful update
    header('location:atten.php');
  } else {
    // Error updating record
    echo "Error: " . mysqli_error($conn);
  }
} else {
  // Update the attendance record with the current time and Identify status
  $current_time = date("H:i:s");
  $query = "UPDATE attendance SET timeout1 = '$current_time', Identify = 'Out' WHERE UserID = '$UserID' AND date = '$current_date'";
  $result = mysqli_query($conn, $query);

  if ($result) {
    // Successful update
    header('location:atten.php');
  } else {
    // Error updating record
    echo "Error: " . mysqli_error($conn);
  }
}

// Close the database connection
mysqli_close($conn);
?>
