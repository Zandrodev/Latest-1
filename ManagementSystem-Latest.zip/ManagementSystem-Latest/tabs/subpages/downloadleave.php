<?php
include('admin/connection.php');
// Retrieve the attachment ID from the query string
$attachment_id = mysqli_real_escape_string($conn, $_GET['attachmentid']);

// Retrieve the attachment details from the database
$query = "SELECT * FROM leaveattachment WHERE attachmentID = $attachment_id";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

// Serve the file to the user
$filename = $row['attachmentName'];
$filepath = $row['attachmentpath'];
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
readfile($filepath);
exit();
?>