<?php
include("Admin/connection.php");
date_default_timezone_set('Asia/Manila');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();
$UserID = $_SESSION['UserID'];
$current_date = date('Y-m-d'); // add semicolon to end of line

// Get the user ID and attendance status from the form
if (isset($_POST['Status2'])) {
  $current_time = date("H:i:s");
  $query = "UPDATE attendance SET timein2 = '$current_time', Identify = 'In' WHERE UserID = '$UserID' AND date = '$current_date'";

  $result = mysqli_query($conn, $query);
  if ($result) {
    // Successful update
    header('location:atten.php');
  } else {
    // Error updating record
    echo "Error: " . mysqli_error($conn);
  }
}

// Close the database connection
mysqli_close($conn);
?>