<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "demologin";

$conn = mysqli_connect($host,$username,$password,$dbname);

// Get the user ID from the URL parameter
$requestID = $_GET['requestID'];

// Query the database to get the user information
$query = "SELECT * FROM leaverequest WHERE requestID = $requestID";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

$attachment_query = "SELECT attachmentName, requestID, attachmentID FROM leaveattachment WHERE requestID = $requestID";
$attachment_result = mysqli_query($conn, $attachment_query);
$attach = mysqli_fetch_assoc($attachment_result);

$leave_query = "SELECT comment, rating FROM leavefeedback WHERE requestID = $requestID";
$leave_result = mysqli_query($conn, $leave_query);
$leave = mysqli_fetch_assoc($leave_result);

?>




<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <title>Dashboard</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="fileleaveview.css">
    <link href='Admin/boxicons-2.1.4/css/boxicons.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">

     <?php 
include("auth.php");
?>

   </head>
<body>

  <div class="sidebar">
    <div class="logo-details">
      <div class="logo_name">
          <img class="Images" src="img/est-transparent.png">
      </div>
        <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
      <li>
        <a href="dashemployee.php">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
    
     <li>
       <a href="atten.php">
         <i class='bx bx-chat' ></i>
         <span class="links_name">Attendance</span>
       </a>
       <span class="tooltip">Attendance</span>
     </li>
     <li>
       <a href="taskcheck.php">
         <i class='bx bx-pie-chart-alt-2' ></i>
         <span class="links_name">Task Check</span>
       </a>
       <span class="tooltip">Task Check</span>
     </li>
     <li>
       <a href="fileleavecheck.php">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Filing Leave</span>
       </a>
       <span class="tooltip">Filing Leave</span>
     </li>
     <li>
     <li class="profile">
         <div class="profile-details">
           <!--<img src="profile.jpg" alt="profileImg">-->
           <div class="name_job">
             <div class="name"><?php
               echo " " .$_SESSION['Name']
               ?></div>
             <div class="job"><?php
               echo " " .$_SESSION['Department']
               ?></div>
           </div>
         </div>
         <form action="logout.php" method="POST">

         <button type="submit" class='bx bx-log-out' id="log_out" ></i>
           </form>
     </li>
    </ul>
  </div>
  <div class="topd">
        <h1>University of Cebu Banilad<h1>
</div>
  <section class="home-section">
      <div class="text">
      <div class="top">
        <div>
            <img src ="img/add.png">
            <div>Filing Leave</div>
            <?php 
            $status = $row['Status'];
if ($status == 'Approved') {
  echo '<div class="stat" style="background-color:green; color: white;">' . $status . '</div>';
} elseif ($status == 'Rejected') {
    echo '<div class="stat" style="background-color:red; color: white;">' . $status . '</div>';
  } else {
    echo '<div class="stat">' . $status . '</div>';
  }
?>
</div>
<form method="post" action="fileleavedb.php" enctype="multipart/form-data">
    <div>
    <?php echo '<div>
    <label>Type: </label>' . $row['Type'] . '</div>'?>
    <?php echo '<div>
    <label>Reason: </label>' . $row['Reason'] . '</div>'?>
    <?php echo '<div>
    <label>Start Date: </label>' . $row['StartDate'] . '</div>'?>
    <?php echo '<div>
    <label>End Date: </label>' . $row['EndDate'] . '</div>'?>
   
</div>
<div>
    <div>
        <p> Attachment</p>
    <?php 
    echo  '<img class="pic" src="img/attachments.png">';
    ?>
    </div>
    <div>
        <?php
    echo "<a href='downloadleave.php?attachmentid=" . $attach['attachmentID'] . "'>" . $attach['attachmentName'] . "</a>";
    ?>
    </div>
</div>
</form>
</div>
<div class ="bottom">
<div>
  <?php
    if (!$leave) {
      echo "No feedback";
    } else {
      $data = $leave['rating'];
      if ($data == 1) {
        echo "Feedback: ★";
      } else if ($data == 2) {
        echo "Feedback: ★★";
      } else if ($data == 3) {
        echo "Feedback: ★★★";
      } else if ($data == 4) {
        echo "Feedback: ★★★★";
      } else if ($data == 5) {
        echo "Feedback: ★★★★★";
      } else {
        echo "Unknown data.";
      }
    }
    ?>
</div>
  <div><?php if (empty($leave['comment'])) {
  echo "No comment";
} else {
  echo "" . $leave['comment'] . "";
} ?></div>
</div>
</div>
  </section>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script src="scripttest.js"></script>
</body>
</html>
