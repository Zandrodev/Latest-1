<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Your Password In Php</title>
    <link rel="stylesheet" href="forgotsuccess.css">
</head>

<body>
    <img class="images" src="img/est-transparent.png">
    <div id="container">
        <h2>Recovery Successful</h2>
        <p>Password changed successfully</p>
        <a href="loginpage.php">Go back to log in page</a>
    </div>
</body>

</html>